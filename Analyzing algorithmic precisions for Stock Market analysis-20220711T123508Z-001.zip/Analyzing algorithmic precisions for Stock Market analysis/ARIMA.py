%matplotlib inline
import os.path
import datetime

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pandas_datareader.data as web
import statsmodels.api as sm
import statsmodels.tsa.api as smt

from statsmodels.tsa.arima_model import ARIMA, ARIMAResults
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

from matplotlib.pylab import rcParams
rcParams['figure.figsize'] = 15, 6
plt.style.use('ggplot')

symbol = 'MSFT'
source = 'yahoo'
start_date = '1986-03-13'
end_date = '2018-03-12'
predict_days = 2
filename = '{}_{}_to_{}.csv'.format(symbol, start_date, end_date)

start = datetime.datetime.strptime(start_date, "%Y-%m-%d")
end = datetime.datetime.strptime(end_date, "%Y-%m-%d")

if os.path.isfile(filename):
    data = pd.read_csv(filename, parse_dates=True, index_col=0)
else:
    data = web.DataReader(symbol, source, start, end)
    data.to_csv(filename)

data.tail(5)

from matplotlib.pylab import rcParams
rcParams['figure.figsize'] = 15, 6
plt.style.use('ggplot')
original_data = data.fillna(method='ffill')

ran = pd.date_range(start_date, end_date, freq = 'D')
original_data = pd.Series(original_data['Close'], index = ran)

plt.plot(original_data)
plt.show()

original_data = original_data.fillna(method='ffill')

split = len(original_data) - predict_days
train_data, prediction_data = original_data[0:split], original_data[split:]

train_data.tail(5)

didive_large_series_by = 10
fig, axes = plt.subplots(1, 2, figsize=(15,4))
fig = plot_acf(train_data,
               lags = abs(train_data.shape[0]/didive_large_series_by),
               ax=axes[0])
fig = plot_pacf(train_data,
                lags = abs(train_data.shape[0]/didive_large_series_by),
                ax=axes[1])

symbol_diff = train_data - train_data.shift()
symbol_diff = symbol_diff.dropna()
symbol_diff.head(4)

plt.plot(symbol_diff)
plt.title('First Difference Time Series Plot')
plt.show()

from collections import namedtuple

ADF = namedtuple('ADF', 'adf pvalue usedlag nobs critical icbest')
stationarity_results = ADF(*smt.adfuller(train_data))._asdict()
significance_level = 0.01

if (stationarity_results['pvalue'] > significance_level):
    message = 'For p-value={:0.4f}, the time series are probably non-stationary'
    print(message.format(stationarity_results['pvalue']))
else:
    message = 'For p-value={:0.4f}, the time series are probably stationary'
    print(message.format(stationarity_results['pvalue']))

print(stationarity_results['critical'])

order = (1, 0, 1) 
if stationarity_results['pvalue'] > 0.01:
    order = (1, 1, 1)

mod = ARIMA(train_data, order = order, freq = 'D')

results = mod.fit()
print(results.summary())
print('DW test is {}'.format(sm.stats.durbin_watson(results.resid.values)))

prediction = results.predict(prediction_data.index[0],
                             prediction_data.index[-1],
                             typ='levels')
prediction.tail(predict_days)

fig, ax = plt.subplots(figsize=(12, 8))
plt.title("Actual Close price Vs. Forecasted Values")
ax = original_data.ix[len(original_data)-predict_days*10:].plot(ax=ax)
fig = results.plot_predict(prediction_data.index[0],
                           prediction_data.index[-1],
                           dynamic=True,
                           ax=ax,
                           plot_insample=False)
legend = ax.legend(loc='upper left')

mean_forecast_error = original_data.ix[-predict_days:].sub(prediction).mean()
print('Mean forecast error is {:.2%}'.format(abs(mean_forecast_error)))

naive_prediction = original_data.tail(predict_days+1).shift(1).tail(predict_days)
percentage_change = abs((prediction/naive_prediction-1) *100)
df = pd.concat([naive_prediction, prediction, percentage_change], axis=1)
df.columns = ['Original', 'Predicted', '% Prediction Diff']
df

mean_errors = []
for number_of_days in range(1, 20):
    split = len(original_data) - number_of_days
    train_data, prediction_data = original_data[0:split], original_data[split:]
    mod = ARIMA(train_data, order = (1, 1, 1), freq = 'D')
    results = mod.fit(disp=0)
    prediction = results.predict(prediction_data.index[0],
                                 prediction_data.index[-1],
                                 typ='levels')
    original_data_sample = original_data.ix[-number_of_days:]
    mean_errors.append(abs(original_data_sample.sub(prediction).mean()))

plt.plot(mean_errors)
plt.show()